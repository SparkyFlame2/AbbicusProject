
#!/bin/bash
echo "Installing ABBICUS dependencies..."
pip3 install pillow
pip3 install pygame
echo "Done."
